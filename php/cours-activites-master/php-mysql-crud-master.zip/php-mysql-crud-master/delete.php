<?php
/**** Supprimer une randonnée ****/
